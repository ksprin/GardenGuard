# Change COM4 to your actual port, and BaudRate to match Serial.begin() in Arduino
$port = New-Object System.IO.Ports.SerialPort COM5,115200
$port.Open()

while ($true) {
    $line = $port.ReadLine()
    Write-Host $line
}

