param(
    [string]$Port = "COM6",
    [int]$Baud = 9600,
    [int]$StopAfterSeconds = 20,
    [string]$LogFile = "C:\Users\Halsey Robinson\AppData\Roaming\Godot\app_userdata\GardenGuard\data\recorded\log 1.txt",
    [string]$CheckFile = "C:\Users\Halsey Robinson\AppData\Roaming\Godot\app_userdata\GardenGuard\data\check_run.txt"
)

# Validate port exists
$availablePorts = [System.IO.Ports.SerialPort]::GetPortNames()
if ($availablePorts -notcontains $Port) { Write-Host "Invalid port"; exit 1 }

# Serial setup
$serial = New-Object System.IO.Ports.SerialPort $Port, $Baud
$serial.NewLine = "`n"
$serial.ReadTimeout = 0

# Open port
$openError = $false
$ErrorActionPreference = "Stop"
try { $serial.Open() } catch [System.UnauthorizedAccessException] { Write-Host "Access denied"; $openError = $true } catch { Write-Host "Could not open port"; $openError = $true }
$ErrorActionPreference = "Continue"
if ($openError -or -not $serial.IsOpen) { exit 1 }

Write-Host "Port opened"

# Timer resets when serial data is received
$lastReadTime = Get-Date
$buf = ""

while ($serial.IsOpen) {

    # Read check file simply
    if (Test-Path $CheckFile) {
        $fileValue = (Get-Content -Path $CheckFile -Raw).Trim().ToLower()
        if ($fileValue -ne "true") {
            Write-Host "Stopped by check file"
            break
        }
    } else {
        # If the file doesn't exist, stop too
        Write-Host "Check file missing, stopping"
        break
    }

    # Time limit check
    if ($StopAfterSeconds -gt 0) {
        if (((Get-Date) - $lastReadTime).TotalSeconds -ge $StopAfterSeconds) {
            Write-Host "Time limit reached"
            break
        }
    }

    # Non-blocking serial read
    if ($serial.BytesToRead -gt 0) {
        $chunk = $serial.ReadExisting()
        if ($chunk) {
            $lastReadTime = Get-Date
            $chunk = $chunk -replace "`r",""
            $buf += $chunk

            while ($buf.Contains("`n")) {
                $i = $buf.IndexOf("`n")
                $line = $buf.Substring(0, $i)
                $buf  = $buf.Substring($i + 1)
                if ($line.Trim() -ne "") {
                    $ts = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
                    $output = "$ts$line"  # no space between timestamp and line
                    $output | Out-File -FilePath $LogFile -Append -Encoding utf8
                }
            }
        }
    } else {
        Start-Sleep -Milliseconds 30
    }
}

if ($serial.IsOpen) {
    $serial.Close()
    Write-Host "Port closed"
}
