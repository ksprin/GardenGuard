param(
    [string]$Port,
    [int]$Baud,
    [double]$StopDuration,
    [string]$CheckFile,
    [string]$InFile,
    [string]$OutFile
)

# Validate port exists
$availablePorts = [System.IO.Ports.SerialPort]::GetPortNames()
if ($availablePorts -notcontains $Port) { Write-Host "[OUT] Invalid port"; exit 1 }

# Serial setup
$serial = New-Object System.IO.Ports.SerialPort $Port, $Baud
$serial.NewLine = "`n"
$serial.ReadTimeout = 0

# Open port
$openError = $false
$ErrorActionPreference = "Stop"
try { 
    $serial.Open() 
} catch [System.UnauthorizedAccessException] { 
    Write-Host "[OUT] Access denied"; 
    $openError = $true 
} catch { 
    Write-Host "[OUT] Could not open port"; 
    $openError = $true 
}
$ErrorActionPreference = "Continue"
if ($openError -or -not $serial.IsOpen) { exit 1 }

Write-Host "[OUT] Port opened"

# Timer resets when serial data is received
$lastReadTime = Get-Date
$buf = ""

while ($serial.IsOpen) {

    # Read check file simply
    $fileValue = (Get-Content -Path $CheckFile -Raw).Trim().ToLower()
    if ($fileValue -ne "capture_serial_output") {
        Write-Host "[OUT] Stopped by check file"
        break
    }

    # Time limit check
    if ($StopDuration -gt 0) {
        if (((Get-Date) - $lastReadTime).TotalSeconds -ge $StopDuration) {
            Write-Host "[OUT] Time limit reached"
            break
        }
    }

    # Push device output to OutFile (no timestamps)
    if ($serial.BytesToRead -gt 0) {
        $chunk = $serial.ReadExisting()
        if ($chunk) {
            $lastReadTime = Get-Date
            $chunk = $chunk -replace "`r",""
            $buf += $chunk

            while ($buf.Contains("`n")) {
                $i = $buf.IndexOf("`n")
                $line = $buf.Substring(0, $i)
                $buf  = $buf.Substring($i + 1)
                if ($line.Trim() -ne "") {
                    $line | Out-File -FilePath $OutFile -Append -Encoding utf8
                    Write-Host "[IO] Appended one line to OutFile"
                }
            }
        }
    } else {
        Start-Sleep -Milliseconds 30
    }

    # Read from InFile and send to serial if non-empty and not 'nothing'
    if (Test-Path $InFile) {
        $inRaw = Get-Content -Path $InFile -Raw

        # Ignore if InFile is empty or equals "nothing"
        if ($null -ne $inRaw) {
            $inTrim = $inRaw.Trim()
        } else {
            $inTrim = ""
        }

        if ($inTrim -and ($inTrim.ToLower() -ne "nothing")) {
            Write-Host "[IO] Sending data from InFile to serial"
            $toSend = $inRaw

            # Erase contents of InFile
            Set-Content -Path $InFile -Value ""
            Write-Host "[IO] Cleared InFile"

            # Write exactly what's provided to serial
            $ErrorActionPreference = "Stop"
            try { 
                $serial.Write($toSend) 
                Write-Host "[IO] Sent data to serial"
            } catch { 
                Write-Host "[OUT] Serial write failed" 
            }
            $ErrorActionPreference = "Continue"
        }
    }
}

if ($serial.IsOpen) {
    $serial.Close()
    Write-Host "[OUT] Port closed"
}
