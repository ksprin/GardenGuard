(Get-WmiObject Win32_SerialPort |
    Select-Object DeviceID, Caption |
    ForEach-Object { @($_.DeviceID, $_.Caption) })