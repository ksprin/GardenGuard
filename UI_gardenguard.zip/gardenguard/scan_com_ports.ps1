param(
    [int]$Baud,
    [double]$StopDuration,
    [string]$Trigger_String,
    [string]$CheckRun
)

# If CheckRun is not provided or does not exist, exit early
if ([string]::IsNullOrWhiteSpace($CheckRun) -or -not (Test-Path $CheckRun)) {
    Write-Host ""
    exit
}

# Get available COM ports
$portNames = Get-WmiObject Win32_SerialPort | Select-Object -ExpandProperty DeviceID

# Open all ports that can be opened
$ports = @()
foreach ($p in $portNames) {
    $serial = New-Object System.IO.Ports.SerialPort $p, $Baud
    $serial.NewLine     = "`n"
    $serial.ReadTimeout = 0

    try {
        $serial.Open()
    } catch {
        continue
    }

    if ($serial.IsOpen) {
        $ports += [PSCustomObject]@{
            PortName = $p
            Serial   = $serial
            Buffer   = ""
        }
    }
}

$foundPort = ""
$startTime = Get-Date

while (($foundPort -eq "") -and ((Get-Date) - $startTime).TotalSeconds -lt $StopDuration) {

    # Stop if CheckRun file disappears
    if (-not (Test-Path $CheckRun)) {
        Write-Host ""
        break
    }

    # Safely read CheckRun content
    $val = Get-Content -Path $CheckRun -Raw -ErrorAction SilentlyContinue

    # If we couldn't read anything, stop
    if ($null -eq $val) {
        Write-Host ""
        break
    }

    $val = $val.Trim().ToLower()

    if ($val -ne "scan_com_ports") {
        Write-Host ""
        break
    }

    foreach ($item in $ports) {
        $sp = $item.Serial

        if ($sp.BytesToRead -gt 0) {
            $chunk = $sp.ReadExisting()
            if ($chunk) {
                $chunk = $chunk -replace "`r",""
                $item.Buffer += $chunk

                while ($item.Buffer.Contains("`n")) {
                    $i    = $item.Buffer.IndexOf("`n")
                    $line = $item.Buffer.Substring(0, $i)
                    $item.Buffer = $item.Buffer.Substring($i + 1)

                    if ($line.StartsWith($Trigger_String)) {
                        $foundPort = $item.PortName
                        break
                    }
                }
            }
        }

        if ($foundPort -ne "") { break }
    }

    if ($foundPort -eq "") {
        Start-Sleep -Milliseconds 30
    }
}

# Close all opened serial ports
foreach ($item in $ports) {
    if ($item.Serial.IsOpen) { $item.Serial.Close() }
}

# REQUIRED OUTPUT ONLY
if ($foundPort -ne "") {
    Write-Host $foundPort
} else {
    Write-Host ""
}
